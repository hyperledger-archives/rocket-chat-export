/*
 * SPDX-License-Identifier: Apache-2.0
 */

import { MyAssetContract } from './my-asset-contract';
export { MyAssetContract } from './my-asset-contract';

export const contracts: any[] = [ MyAssetContract ];
