/*
 * SPDX-License-Identifier: Apache-2.0
 */

import { Object, Property } from 'fabric-contract-api';

@Object()
export class TestAsset {

    @Property()
    public value: string;
    @Property()
    public SecondValue: string;

    @Property() // ID Iterm number
    public productID: string;

    @Property() // Product Type
    public productType: string;

    @Property()
    public price: string;

    @Property()
    public quantity: string;

}
