/*
 * SPDX-License-Identifier: Apache-2.0
 */

import { Context, Contract, Info, Returns, Transaction } from 'fabric-contract-api';
import { SimpleObject } from './simpleObject';

@Info({title: 'MyAs', description: 'My Smart Contract' })
export class MyAssetContractTwo extends Contract {

    constructor() {
        // Unique name when multiple contracts per chaincode file
        super('org.test.trading');
    }

    @Transaction(false)
    @Returns('boolean')
    public async mySimpleObjectExists(ctx: Context, myAssetId: string): Promise<boolean> {
        const buffer = await ctx.stub.getState(myAssetId);
        return (!!buffer && buffer.length > 0);
    }

    @Transaction()
    public async createSimpleObject(ctx: Context, myAssetId: string, value: string): Promise<void> {
        const exists = await this.mySimpleObjectExists(ctx, myAssetId);
        if (exists) {
            throw new Error(`The my asset ${myAssetId} already exists`);
        }
        const myAsset = new SimpleObject();
        myAsset.value = value;
        const buffer = Buffer.from(JSON.stringify(myAsset));
        await ctx.stub.putState(myAssetId, buffer);
    }




}
