import { Object , Property } from 'fabric-contract-api';

@Object()
export class OrderProducts {

    @Property() // ID Iterm number
    public productID: string;

    @Property() // Product Type
    public productType: string;

    @Property()
    public price: string;

    @Property()
    public quantity: string;
}
