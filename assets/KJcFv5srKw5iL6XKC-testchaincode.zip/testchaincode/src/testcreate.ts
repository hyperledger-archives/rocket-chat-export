
import { Object, Property } from 'fabric-contract-api';

@Object()
export class TestClasses {

    @Property()
    public value: string;

}
