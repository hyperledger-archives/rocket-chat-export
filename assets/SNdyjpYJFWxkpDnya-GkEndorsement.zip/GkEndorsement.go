/*

Sample endoresement from ganesh
*/

package main

import (
	"os"

	"github.com/hyperledger/fabric/common/flogging"
	. "github.com/hyperledger/fabric/core/handlers/endorsement/api"
	. "github.com/hyperledger/fabric/core/handlers/endorsement/api/identities"
	"github.com/hyperledger/fabric/protos/peer"
	"github.com/pkg/errors"
)

var logger = flogging.MustGetLogger("main")
var logOutput = os.Stderr

// To build the plugin,
// run:
//   go build -buildmode=plugin -o escc.so plugin.go

// GkEndorsementFactory returns an endorsement plugin factory which returns plugins
// that behave as the default endorsement system chaincod
type GkEndorsementFactory struct {
}

// New returns an endorsement plugin that behaves as the default endorsement system chaincode
func (*GkEndorsementFactory) New() Plugin {
	return &GkEndorsement{}
}

// GkEndorsement is an endorsement plugin that behaves as the default endorsement system chaincode
type GkEndorsement struct {
	SigningIdentityFetcher
}

// Endorse signs the given payload(ProposalResponsePayload bytes), and optionally mutates it.
// Returns:
// The Endorsement: A signature over the payload, and an identity that is used to verify the signature
// The payload that was given as input (could be modified within this function)
// Or error on failure
func (e *GkEndorsement) Endorse(prpBytes []byte, sp *peer.SignedProposal) (*peer.Endorsement, []byte, error) {
	logger.Errorf("hello, world GKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKK -last\n")
	signer, err := e.SigningIdentityForRequest(sp)
	if err != nil {
		return nil, nil, errors.Wrap(err, "failed fetching signing identity")
	}
	// serialize the signing identity
	identityBytes, err := signer.Serialize()
	if err != nil {
		return nil, nil, errors.Wrapf(err, "could not serialize the signing identity")
	}

	// sign the concatenation of the proposal response and the serialized endorser identity with this endorser's key
	signature, err := signer.Sign(append(prpBytes, identityBytes...))
	if err != nil {
		return nil, nil, errors.Wrapf(err, "could not sign the proposal response payload")
	}
	endorsement := &peer.Endorsement{Signature: signature, Endorser: identityBytes}
	return endorsement, prpBytes, nil
}

// Init injects dependencies into the instance of the Plugin
func (e *GkEndorsement) Init(dependencies ...Dependency) error {
	logger.Errorf("hello, world GKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKK -init\n")
	for _, dep := range dependencies {
		sIDFetcher, isSigningIdentityFetcher := dep.(SigningIdentityFetcher)
		if !isSigningIdentityFetcher {
			continue
		}
		e.SigningIdentityFetcher = sIDFetcher

		return nil
	}
	return errors.New("could not find SigningIdentityFetcher in dependencies")
}

/*
copied form url https://github.com/hyperledger/fabric/blob/release-1.2/core/handlers/endorsement/plugin/plugin.go
*/
