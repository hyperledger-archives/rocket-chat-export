#!/bin/bash
cd $1
cryptogen generate --config=$1/crypto-config.yaml
export FABRIC_CFG_PATH=$1
configtxgen -profile ComposerOrdererGenesis -outputBlock $1/composer-genesis.block
configtxgen -profile ComposerChannel -outputCreateChannelTx $1/composer-channel.tx -channelID composerchannel
