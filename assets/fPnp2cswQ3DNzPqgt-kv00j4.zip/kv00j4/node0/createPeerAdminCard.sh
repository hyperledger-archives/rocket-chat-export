#!/bin/bash
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
if [ -z "${HL_COMPOSER_CLI}" ]; then
  HL_COMPOSER_CLI=$(which composer)
fi
echo
COMPOSER_VERSION=$("${HL_COMPOSER_CLI}" --version 2>/dev/null)
COMPOSER_RC=$?
if [ $COMPOSER_RC -eq 0 ]; then
    AWKRET=$(echo $COMPOSER_VERSION | awk -F. '{if ($2<19) print "1"; else print "0";}')
    if [ $AWKRET -eq 1 ]; then
        echo Cannot use $COMPOSER_VERSION version of composer with fabric 1.1, v0.19 or higher is required
        exit 1
    else
        echo Using composer-cli at $COMPOSER_VERSION
    fi
else
    echo 'No version of composer-cli has been detected, you need to install composer-cli at v0.19 or higher'
    exit 1
fi
cd $1


PRIVATE_KEY="${DIR}"/composer/crypto-config/peerOrganizations/americanairlines.kv00j4.hyperledgerhosting.com/users/Admin@americanairlines.kv00j4.hyperledgerhosting.com/msp/keystore/4940606e8f4a08cb66a7819a2ffef34edcdec18d127f9a739082124e4e5b0bc0_sk
CERT="${DIR}"/composer/crypto-config/peerOrganizations/americanairlines.kv00j4.hyperledgerhosting.com/users/Admin@americanairlines.kv00j4.hyperledgerhosting.com/msp/signcerts/Admin@americanairlines.kv00j4.hyperledgerhosting.com-cert.pem
"${HL_COMPOSER_CLI}"  card create -p ./adminCards/americanairlines.json -u PeerAdmin -c "${CERT}" -k "${PRIVATE_KEY}" -r PeerAdmin -r ChannelAdmin --file ./adminCards/americanairlines.card


PRIVATE_KEY="${DIR}"/composer/crypto-config/peerOrganizations/indonesianairlines.kv00j4.hyperledgerhosting.com/users/Admin@indonesianairlines.kv00j4.hyperledgerhosting.com/msp/keystore/c20ac5c912a64590627254ad08158a2a2fb8ac52387dc0709296895746afdaa2_sk
CERT="${DIR}"/composer/crypto-config/peerOrganizations/indonesianairlines.kv00j4.hyperledgerhosting.com/users/Admin@indonesianairlines.kv00j4.hyperledgerhosting.com/msp/signcerts/Admin@indonesianairlines.kv00j4.hyperledgerhosting.com-cert.pem
"${HL_COMPOSER_CLI}"  card create -p ./adminCards/indonesianairlines.json -u PeerAdmin -c "${CERT}" -k "${PRIVATE_KEY}" -r PeerAdmin -r ChannelAdmin --file ./adminCards/indonesianairlines.card


PRIVATE_KEY="${DIR}"/composer/crypto-config/peerOrganizations/jetblue.kv00j4.hyperledgerhosting.com/users/Admin@jetblue.kv00j4.hyperledgerhosting.com/msp/keystore/59d864d2e5353b13fb9df570b44b4c11c8ad6ce0aa1e2243537a201f97f5a562_sk
CERT="${DIR}"/composer/crypto-config/peerOrganizations/jetblue.kv00j4.hyperledgerhosting.com/users/Admin@jetblue.kv00j4.hyperledgerhosting.com/msp/signcerts/Admin@jetblue.kv00j4.hyperledgerhosting.com-cert.pem
"${HL_COMPOSER_CLI}"  card create -p ./adminCards/jetblue.json -u PeerAdmin -c "${CERT}" -k "${PRIVATE_KEY}" -r PeerAdmin -r ChannelAdmin --file ./adminCards/jetblue.card


PRIVATE_KEY="${DIR}"/composer/crypto-config/peerOrganizations/alaskaair.kv00j4.hyperledgerhosting.com/users/Admin@alaskaair.kv00j4.hyperledgerhosting.com/msp/keystore/48cb5229abb87990ab1ba6b1a610ace60461e32157eb16458b399c30592bf064_sk
CERT="${DIR}"/composer/crypto-config/peerOrganizations/alaskaair.kv00j4.hyperledgerhosting.com/users/Admin@alaskaair.kv00j4.hyperledgerhosting.com/msp/signcerts/Admin@alaskaair.kv00j4.hyperledgerhosting.com-cert.pem
"${HL_COMPOSER_CLI}"  card create -p ./adminCards/alaskaair.json -u PeerAdmin -c "${CERT}" -k "${PRIVATE_KEY}" -r PeerAdmin -r ChannelAdmin --file ./adminCards/alaskaair.card

