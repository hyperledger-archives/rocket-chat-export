#!/bin/bash
docker restart $(docker ps -aq)