#!/bin/bash
set -e
ARCH=`uname -m`
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
DOCKER_FILE="${DIR}"/composer/node.yml
ARCH=$ARCH docker-compose -f "${DOCKER_FILE}" down
