#!/bin/bash
set -e
ARCH=`uname -m`
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
DOCKER_FILE="${DIR}"/composer/node.yml
ARCH=$ARCH docker-compose -f "${DOCKER_FILE}" down
ARCH=$ARCH docker-compose -f "${DOCKER_FILE}" up -d
echo "sleeping for 15 seconds to wait for fabric to complete start up"
sleep 15



docker exec -e "CORE_PEER_MSPCONFIGPATH=/etc/hyperledger/msp/users/Admin@americanairlines.kv00j4.hyperledgerhosting.com/msp" peer1.americanairlines peer channel fetch newest -o orderer0.kv00j4.hyperledgerhosting.com:7050 -c composerchannel
docker exec -e "CORE_PEER_MSPCONFIGPATH=/etc/hyperledger/msp/users/Admin@americanairlines.kv00j4.hyperledgerhosting.com/msp" peer1.americanairlines peer channel join -b composerchannel_newest.block


docker exec -e "CORE_PEER_MSPCONFIGPATH=/etc/hyperledger/msp/users/Admin@indonesianairlines.kv00j4.hyperledgerhosting.com/msp" peer1.indonesianairlines peer channel fetch newest -o orderer0.kv00j4.hyperledgerhosting.com:7050 -c composerchannel
docker exec -e "CORE_PEER_MSPCONFIGPATH=/etc/hyperledger/msp/users/Admin@indonesianairlines.kv00j4.hyperledgerhosting.com/msp" peer1.indonesianairlines peer channel join -b composerchannel_newest.block


docker exec -e "CORE_PEER_MSPCONFIGPATH=/etc/hyperledger/msp/users/Admin@jetblue.kv00j4.hyperledgerhosting.com/msp" peer1.jetblue peer channel fetch newest -o orderer0.kv00j4.hyperledgerhosting.com:7050 -c composerchannel
docker exec -e "CORE_PEER_MSPCONFIGPATH=/etc/hyperledger/msp/users/Admin@jetblue.kv00j4.hyperledgerhosting.com/msp" peer1.jetblue peer channel join -b composerchannel_newest.block


docker exec -e "CORE_PEER_MSPCONFIGPATH=/etc/hyperledger/msp/users/Admin@alaskaair.kv00j4.hyperledgerhosting.com/msp" peer1.alaskaair peer channel fetch newest -o orderer0.kv00j4.hyperledgerhosting.com:7050 -c composerchannel
docker exec -e "CORE_PEER_MSPCONFIGPATH=/etc/hyperledger/msp/users/Admin@alaskaair.kv00j4.hyperledgerhosting.com/msp" peer1.alaskaair peer channel join -b composerchannel_newest.block

