package main

import (
	"log"
	"time"

	"github.com/hyperledger/fabric-sdk-go/api/apitxn/chclient"
	fsgConfig "github.com/hyperledger/fabric-sdk-go/pkg/config"
	"github.com/hyperledger/fabric-sdk-go/pkg/fabsdk"
)

const (
	channelID = "mychannel"
	orgName   = "Org1"
	orgAdmin  = "Admin"
	ccID      = "marbles"
)

type HyperledgerConnector interface {
}

func main() {
	cp := fsgConfig.FromFile("./config/config_test.yaml")
	sdk, err := fabsdk.New(cp)
	if err != nil {
		log.Fatalln(err)
	}

	// Channel client is used to query and execute transactions (Org1 is default org)
	chClient, err := sdk.NewClient(fabsdk.WithUser(orgAdmin)).Channel(channelID)
	if err != nil {
		log.Fatalln("Failed to create new channel client: %s", err)
	}
	defer chClient.Close()

	var queryArgs = [][]byte{[]byte("marble1")}

	var invokeArgs = [][]byte{[]byte("marble1"), []byte("jerry")}

	response, err := chClient.Query(chclient.Request{ChaincodeID: ccID, Fcn: "readMarble", Args: queryArgs})
	if err != nil {
		log.Fatalln("Failed to query : %s", err)
	} else {
		log.Println(string(response.Payload))
	}

	eventID := "test([a-zA-Z]+)"

	// Register chaincode event (pass in channel which receives event details when the event is complete)
	notifier := make(chan *chclient.CCEvent)
	rce, err := chClient.RegisterChaincodeEvent(notifier, ccID, eventID)
	if err != nil {
		log.Fatalln("Failed to register cc event: %s", err)
	}

	// Move funds
	response, err = chClient.Execute(chclient.Request{ChaincodeID: ccID, Fcn: "transferMarble", Args: invokeArgs})
	if err != nil {
		log.Fatalln("Failed to transfer: %s", err)
	}

	select {
	case ccEvent := <-notifier:
		log.Println("Received CC event: %s\n", ccEvent)
	case <-time.After(time.Second * 20):
		log.Fatalln("Did NOT receive CC event for eventId(%s)\n", eventID)
	}

	// Unregister chain code event using registration handle
	err = chClient.UnregisterChaincodeEvent(rce)
	if err != nil {
		log.Fatalln("Unregister cc event failed: %s", err)
	}
}
