July 05, 2018 - Los Angeles, LA - bvperepa@us.ibm.com
=====================================================

Network
=======

hlbcadmin@ubuntu:~/go/src/github.com/hyperledger/fabric-samples/basic-network$ docker ps
CONTAINER ID        IMAGE                          COMMAND                  CREATED             STATUS                          PORTS                                                                       NAMES
20afb696f832        hyperledger/fabric-tools       "/bin/bash"              9 minutes ago       Up 9 minutes                                                                                                cli
a62765716708        hyperledger/fabric-peer        "peer node start"        9 minutes ago       Up 9 minutes                    0.0.0.0:8051->8051/tcp, 0.0.0.0:8053->8053/tcp                              peer1.org1.example.com
f62fef834c90        hyperledger/fabric-peer        "peer node start"        9 minutes ago       Up 9 minutes                    0.0.0.0:7051->7051/tcp, 0.0.0.0:7053->7053/tcp                              peer0.org1.example.com
30e22f29feaa        hyperledger/fabric-peer        "peer node start"        9 minutes ago       Up 9 minutes                    0.0.0.0:9051->9051/tcp, 0.0.0.0:9053->9053/tcp                              peer0.org2.example.com
623f88516169        hyperledger/fabric-peer        "peer node start"        9 minutes ago       Up 9 minutes                    0.0.0.0:10051->10051/tcp, 0.0.0.0:10053->10053/tcp                          peer1.org2.example.com
305bcd2c28f1        hyperledger/fabric-orderer     "orderer"                9 minutes ago       Up 9 minutes                    0.0.0.0:7050->7050/tcp                                                      orderer.example.com
a9863c2ab628        hyperledger/fabric-kafka       "/docker-entrypoint.…"   9 minutes ago       Up 9 minutes                    9093/tcp, 0.0.0.0:33025->9092/tcp                                           kafka2
4177ec24064c        hyperledger/fabric-kafka       "/docker-entrypoint.…"   9 minutes ago       Up 9 minutes                    9093/tcp, 0.0.0.0:33024->9092/tcp                                           kafka3
fe21a673aa8c        hyperledger/fabric-kafka       "/docker-entrypoint.…"   9 minutes ago       Up 9 minutes                    9093/tcp, 0.0.0.0:33023->9092/tcp                                           kafka1
a4d2ab2396e3        hyperledger/fabric-kafka       "/docker-entrypoint.…"   9 minutes ago       Up 9 minutes                    9093/tcp, 0.0.0.0:33022->9092/tcp                                           kafka0
ba9f8cdfb986        hyperledger/fabric-couchdb     "tini -- /docker-ent…"   9 minutes ago       Up 9 minutes                    4369/tcp, 9100/tcp, 0.0.0.0:5984->5984/tcp                                  couchdb
53bfdfd22717        hyperledger/fabric-zookeeper   "/docker-entrypoint.…"   9 minutes ago       Up 9 minutes                    0.0.0.0:33021->2181/tcp, 0.0.0.0:33020->2888/tcp, 0.0.0.0:33018->3888/tcp   zookeeper0
c8722b208ef6        hyperledger/fabric-ca          "sh -c 'fabric-ca-se…"   9 minutes ago       Up 9 minutes                    0.0.0.0:7054->7054/tcp                                                      ca1.example.com
9c6f22e842c9        hyperledger/fabric-zookeeper   "/docker-entrypoint.…"   9 minutes ago       Restarting (1) 18 seconds ago                                                                               zookeeper3
8af5d9c32130        hyperledger/fabric-zookeeper   "/docker-entrypoint.…"   9 minutes ago       Up 9 minutes                    0.0.0.0:33015->2181/tcp, 0.0.0.0:33014->2888/tcp, 0.0.0.0:33013->3888/tcp   zookeeper1
634f7aea3397        hyperledger/fabric-ca          "sh -c 'fabric-ca-se…"   9 minutes ago       Up 9 minutes                    0.0.0.0:8054->7054/tcp                                                      ca2.example.com
e47bde73a664        hyperledger/fabric-zookeeper   "/docker-entrypoint.…"   9 minutes ago       Up 9 minutes                    0.0.0.0:33012->2181/tcp, 0.0.0.0:33011->2888/tcp, 0.0.0.0:33010->3888/tcp   zookeeper2


Release
=======

v1.1.0

Platform
========

Ubuntu 
   Static hostname: ubuntu.ibm.com
         Icon name: computer-vm
           Chassis: vm
        Machine ID: 6f11c46b9d1e49df8929202a425968e0
           Boot ID: d87187b7ee3f4904a669bf6edc7e1f06
    Virtualization: vmware
  Operating System: Ubuntu 16.04.4 LTS
            Kernel: Linux 4.15.0-24-generic
      Architecture: x86-64

Tutorial
========

basic-network and fabcar
nodeJS & NodeSDK

Objective
=========

Turn the sample into multi-config consortium based with kafka-zk consensus with enrollment and user registration engineered in from base line sample
Incorporate couchdb into the network as versioned kv object store

Problem
=======

Tutorial Samples - basic-network and fabcar with scaled out customization [two orgs, two peers per org, crypto-gen, kafka and zookeeper based orderer]

Client Log
==========

[hlbcadmin@kopernik basic-network]$ docker exec -e "CORE_PEER_LOCALMSPID=Org1MSP" -e "CORE_PEER_MSPCONFIGPATH=/etc/hyperledger/msp/users/Admin@org1.example.com/msp" peer0.org1.example.com peer channel create -o orderer.example.com:7050 -c mychannel -f /etc/hyperledger/configtx/channel.tx
2018-07-03 15:54:25.032 UTC [channelCmd] InitCmdFactory -> INFO 001 Endorser and orderer connections initialized
Error: got unexpected status: SERVICE_UNAVAILABLE -- will not enqueue, consenter for this channel hasn't started yet
Usage:
  peer channel create [flags]

Flags:
  -c, --channelID string   In case of a newChain command, the channel ID to create.
  -f, --file string        Configuration transaction file generated by a tool such as configtxgen for submitting to orderer
  -t, --timeout int        Channel creation timeout (default 5)

Global Flags:
      --cafile string                       Path to file containing PEM-encoded trusted certificate(s) for the ordering endpoint
      --certfile string                     Path to file containing PEM-encoded X509 public key to use for mutual TLS communication with the orderer endpoint
      --clientauth                          Use mutual TLS when communicating with the orderer endpoint
      --keyfile string                      Path to file containing PEM-encoded private key to use for mutual TLS communication with the orderer endpoint
      --logging-level string                Default logging level and overrides, see core.yaml for full syntax
  -o, --orderer string                      Ordering service endpoint
      --ordererTLSHostnameOverride string   The hostname override to use when validating the TLS connection to the orderer.
      --tls                                 Use TLS when communicating with the orderer endpoint
  -v, --version                             Display current version of fabric peer server

Server Log
==========
  
2018-07-03 15:54:25.032 UTC [orderer/common/server] Deliver -> DEBU 4e9 Starting new Deliver handler
2018-07-03 15:54:25.032 UTC [common/deliver] Handle -> DEBU 4ea Starting new deliver loop for 172.18.0.14:49750
2018-07-03 15:54:25.032 UTC [common/deliver] Handle -> DEBU 4eb Attempting to read seek info message from 172.18.0.14:49750
2018-07-03 15:54:25.047 UTC [orderer/common/server] Broadcast -> DEBU 4ec Starting new Broadcast handler
2018-07-03 15:54:25.047 UTC [orderer/common/broadcast] Handle -> DEBU 4ed Starting new broadcast loop for 172.18.0.14:49752
2018-07-03 15:54:25.047 UTC [orderer/common/broadcast] Handle -> WARN 4ee [channel: mychannel] Rejecting broadcast of message from 172.18.0.14:49752 with SERVICE_UNAVAILABLE: rejected by Consenter: will not enqueue, consenter for this channel hasn't started yet
2018-07-03 15:54:25.047 UTC [orderer/common/server] func1 -> DEBU 4ef Closing Broadcast stream
2018-07-03 15:54:25.050 UTC [common/deliver] Handle -> WARN 4f0 Error reading from 172.18.0.14:49750: rpc error: code = Canceled desc = context canceled
2018-07-03 15:54:25.050 UTC [orderer/common/server] func1 -> DEBU 4f1 Closing Deliver stream
2018-07-03 15:55:35.747 UTC [orderer/consensus/kafka] try -> DEBU 4f2 [channel: testchainid] Connecting to the Kafka cluster