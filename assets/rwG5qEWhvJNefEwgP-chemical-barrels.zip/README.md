# Chemical Barrels on Blockchain

This is a demonstration of a "imaginated" use-case for a critical industry field which is applied to blockchain
using Hyperledger Fabric and Composer.

## Description

In chemical and toxic/dangerous liquid industry special barrels (with special connector-types) are used to transport the liquids and keep them safe.
It is extremely important that every process like transportation or manufactoring of such barrels is not only logged but executed without failures.
In such a network where different parties like transportation-company, barrel-manufacturer, liquid-filler, auditor/regulator and end-customer exist, every member is restricted with permissions related to his business role. A transportation company, f.e., must not be able to edit any critical information (like barrel content) and must not have access to information it doesn't allowed to (like liquid costs). A transportation-company is commissioned to safely deliver the (filled) barrels from position A to destination B and handover it to the entitled party if contract conditions are valid.

## Structure

This repository contains following scenarios and implementations related to them:

*processes*

- [x] barrel order process
- [ ] manufactoring initiation
- [ ] blocking a barrel
- [ ] validation barrel usage

## Definition of business processes

### Order new barrel as a customer

![new barrel ordering process][barrel_ordering_sequence]

[barrel_ordering_sequence]: https://www.dropbox.com/s/x6jt7gbtrd278l7/sequence_chemical_barrel_without_events_english.png?raw=1
