'use strict'
var contracts = require('@monax/legacy-contracts')
var fs = require('fs')
var encoding = require("encoding");
var http = require('http')
var keccak_256 = require('js-sha3').keccak_256;
var chainConfig = require('/home/1070933/.monax/ErisChainConfig.json')
var address_Dao = require('./jobs_output.json').deployStorageK
var abi_Dao = JSON.parse(fs.readFileSync('./abi/' + address_Dao, 'utf8'))
var accounts = require('./accounts.json')
var chainUrl
var manager
var contract
var server
var hostname = 'localhost';
var port = 8002;
chainUrl = chainConfig.chainURL;
var manager_full = contracts.newContractManagerDev(chainUrl, chainConfig.primaryAccount)
var contract_Dao = manager_full.newContractFactory(abi_Dao).at(address_Dao)



//TAKE THIS CODE DOWN HERE
//notice var t is prepended with 0x

var t = "0x0373ecbb94edf2f4f6c09f617725e7e2d2b12b3bccccfe9674c527c83f50c89055";
var t2 = "0373ecbb94edf2f4f6c09f617725e7e2d2b12b3bccccfe9674c527c83f50c89055";
console.log("keccak 0xkey: " + keccak_256(t));
console.log("keccak key: " + keccak_256(t2));

contract_Dao.set(t.valueOf(), function (error, res) {
    console.log("set: " + res)
    contract_Dao.get(function (e, r) {
        console.log("res: " + r)
        contract_Dao.get2(function (e2, r2) {
            console.log("res2: " + r2)

        })
    })



})
