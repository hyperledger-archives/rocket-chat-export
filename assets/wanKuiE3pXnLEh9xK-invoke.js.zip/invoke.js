'use strict';

var Fabric_Client = require('fabric-client');
var path = require('path');
var util = require('util');
var os = require('os');
var fs = require('fs-extra');
//
var fabric_client = new Fabric_Client();
let data = fs.readFileSync(path.join(__dirname, "gda_crypt/tlsca.gda.example.com-cert.pem"));
let grpcOpts = {
				pem: Buffer.from(data).toString(),
				'ssl-target-name-override': 'peer0.gda.example.com'
			};
let grpc_orderer=fs.readFileSync(path.join(__dirname,"orderer_crypt/tlsca.example.com-cert.pem"))
let grpc_orderer_opts={
                      pem: Buffer.from(grpc_orderer).toString(),
                      'ssl-targer-name-override':'orderer.example.com'


}
var orderer=fabric_client.newOrderer('grpcs://localhost:7050',grpc_orderer_opts)
// setup the fabric network
var channel = fabric_client.newChannel('property');
var peer = fabric_client.newPeer('grpcs://localhost:9051',grpcOpts);
var peerevent=fabric_client.newPeer('grpcs://localhost:9053',grpcOpts)
channel.addPeer(peer);
channel.addOrderer(orderer);

//
var member_user = null;
var store_path = path.join(__dirname, 'keystore');
console.log('Store path:'+store_path);
var tx_id = null;

// create the key value store as defined in the fabric-client/config/default.json 'key-value-store' setting
Fabric_Client.newDefaultKeyValueStore({ path: store_path
}).then((state_store) => {
	// assign the store to the fabric client
	fabric_client.setStateStore(state_store);
	var crypto_suite = Fabric_Client.newCryptoSuite();
	// use the same location for the state store (where the users' certificate are kept)
	// and the crypto store (where the users' keys are kept)
	var crypto_store = Fabric_Client.newCryptoKeyStore({path: store_path});
	crypto_suite.setCryptoKeyStore(crypto_store);
	fabric_client.setCryptoSuite(crypto_suite);
         
   

	// get the enrolled user from persistence, this user will sign all requests
	return fabric_client.getUserContext('admin', true);
}).then((user_from_store) => {
	if (user_from_store && user_from_store.isEnrolled()) {
		console.log('Successfully loaded admin from persistence');
		member_user = user_from_store;
	} else {
		throw new Error('Failed to get admin.... run registerUser.js');
	}

	
	var error_message = null;
	async function sendtransaction()
{   
	//console.log(fabric_client)

	tx_id = await fabric_client.newTransactionID();
	var tx_id_string = tx_id.getTransactionID();
	console.log("Assigning transaction_id: ", tx_id._transaction_id);
	var request = {
		//targets: let default to the peer assigned to the client
		chaincodeId: 'mycc',
		fcn: 'createProperty',
		args: ['PROPERTY4','33','kerla','APPROVED','MR pink'],
		chainId: 'property',
		txId: tx_id
	};
	let results = await channel.sendTransactionProposal(request);

	var proposalResponses = results[0];
		var proposal = results[1];

		// lets have a look at the responses to see if they are
		// all good, if good they will also include signatures
		// required to be committed
		var all_good = true;
		for (var i in proposalResponses) {
			let one_good = false;
			if (proposalResponses && proposalResponses[i].response &&
				proposalResponses[i].response.status === 200) {
				one_good = true;
				console.log('invoke chaincode proposal was good');
			} else {
				console.log('invoke chaincode proposal was bad');
			}
			all_good = all_good & one_good;
		}
		if (all_good) {
			console.log(util.format(
				'Successfully sent Proposal and received ProposalResponse: Status - %s, message - "%s", metadata - "%s", endorsement signature: %s',
				proposalResponses[0].response.status, proposalResponses[0].response.message,
				proposalResponses[0].response.payload, proposalResponses[0].endorsement.signature));

			// wait for the channel-based event hub to tell us
			// that the commit was good or bad on each peer in our organization
			var promises = [];
			let channel_event_hub = channel.newChannelEventHub(peerevent);
			let start_block =null;
			//let event_hubs = channel.getChannelEventHubsForOrg();
			//console.log(channel_event_hub);
			let event_monitor = new Promise((resolve, reject) => {
				let handle = setTimeout(() => {
					// do the housekeeping when there is a problem
					channel_event_hub.unregisterTxEvent(tx_id);
					console.log('Timeout - Failed to receive the transaction event');
					reject(new Error('Timed out waiting for block event'));
				}, 50000);
			
				channel_event_hub.registerTxEvent((event_tx_id, status, block_num) => {
					clearTimeout(handle);
					//channel_event_hub.unregisterTxEvent(event_tx_id); let the default do this
					console.log('Successfully received the transaction event');
					//storeBlockNumForLater(block_num);
					resolve(status);
				}, (error)=> {
					clearTimeout(handle);
					console.log('Failed to receive the transaction event ::'+error);
					reject(error);
				},
					// when this `startBlock` is null (the normal case) transaction
					// checking will start with the latest block
					{startBlock:start_block}
					// notice that `unregister` is not specified, so it will default to true
					// `disconnect` is also not specified and will default to false
				);
			});
                        
		    console.log(channel) 
			let send_trans =await channel.sendTransaction({proposalResponses: results[0], proposal: results[1]});
            


			

			
			return Promise.all([event_monitor, send_trans]).then((result)=>{
				console.log(result);
			})
				
			}
			
		};
	


	sendtransaction();
});






